EXEC dwh.usp_EnsureIndexes_ForEnv @Env=N'TST';
-- controle queries staan in canvas �Indexes & Keys�
