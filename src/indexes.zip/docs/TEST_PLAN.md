# TESTS_GUIDE

## Smoke tests
- Schema's bestaan.
- Config- en logtabellen bestaan.
- Selects leveren ≥ 0 rijen.

## Integratie
- Run per proces simuleert insert/update/delete paden en schrijft logging.
